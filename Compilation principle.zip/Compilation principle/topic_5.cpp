#include <iostream>
#include <vector>
#include <string>
#include <utility>
#include <map>
#include <algorithm>
#include <iomanip>
#include <set>

using namespace std;

string end_c[] = {"i", "+", "-", "/", "*", "=", "(", ")"};
string no_end_c[] = {"S`", "S", "E", "T", "F"};
string ch[] = {"i", "+", "-", "/", "*", "=", "(", ")", "$", "S", "E", "T", "F", "S`"};
vector<vector<pair<char, int>>> act;
bool is_end_char(string &te);
void find_frist(vector<pair<string, vector<string>>> &G, map<string, vector<string>> &FRIST, string &tar_c, vector<string> &tar_vec);
void find_follow(vector<pair<string, vector<string>>> &G, map<string, vector<string>> &FOLLOW, map<string, vector<string>> &FRIST);
void find_select(vector<pair<string, vector<string>>> &G, map<string, vector<string>> &FOLLOW,
                 map<string, vector<string>> &FRIST, vector<vector<string>> &SELECT);
void cout_set(map<string, vector<string>> &FOLLOW, map<string, vector<string>> &FRIST);
void find_closure(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &J, set<pair<int, int>> &I, map<string, vector<string>> &FOLLOW, int row);
void find_go(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &I, set<pair<int, int>> &J, string &X, map<string, vector<string>> &FOLLOW, int row);
void find_items(vector<pair<string, vector<string>>> &G, vector<set<pair<int, int>>> &ITEMS, map<string, vector<string>> &FOLLOW);
void print_set(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &te);
void analysis(vector<pair<string, vector<string>>> &G, vector<string> &tar_str);

int main()
{
    // 初始化文法
    vector<pair<string, vector<string>>> G;
    G.resize(10);
    G[0] = make_pair("S`", vector<string>{"S"});
    G[1] = make_pair("S", vector<string>{"i", "=", "E"});
    G[2] = make_pair("E", vector<string>{"E", "+", "T"});
    G[3] = make_pair("E", vector<string>{"E", "-", "T"});
    G[4] = make_pair("E", vector<string>{"T"});
    G[5] = make_pair("T", vector<string>{"T", "*", "F"});
    G[6] = make_pair("T", vector<string>{"T", "/", "F"});
    G[7] = make_pair("T", vector<string>{"F"});
    G[8] = make_pair("F", vector<string>{"(", "E", ")"});
    G[9] = make_pair("F", vector<string>{"i"});

    // 读入
    vector<string> tar_str;
    string token;
    while (getline(cin, token, ' '))
    {
        if (token[1] == 'I')
        {
            tar_str.push_back("i");
        }
        if (token[1] == 'O')
        {
            tar_str.push_back(string(1, token[4]));
        }
        if (token[1] == 'D')
        {
            tar_str.push_back(string(1, token[4]));
        }
    }
    tar_str.push_back("$");

    // 输出转换后的字符串
    cout << "converted string  :  ";
    for (int i = 0; i < tar_str.size(); i++)
    {
        cout << tar_str[i] << " ";
    }
    cout << endl;

    // 计算frist集
    map<string, vector<string>> FRIST;
    for (int i = 0; i < 8; i++)
    {
        FRIST[end_c[i]] = vector<string>{end_c[i]};
    }
    for (int i = 4; i >= 0; i--)
    {
        vector<string> te;
        find_frist(G, FRIST, no_end_c[i], te);
        FRIST[no_end_c[i]] = te;
    }

    // 计算follow集
    map<string, vector<string>> FOLLOW;
    for (int i = 4; i >= 0; i--)
    {
        FOLLOW[no_end_c[i]] = vector<string>{};
    }
    FOLLOW["S`"].push_back("$");
    find_follow(G, FOLLOW, FRIST);
    find_follow(G, FOLLOW, FRIST);
    find_follow(G, FOLLOW, FRIST);
    find_follow(G, FOLLOW, FRIST);

    vector<set<pair<int, int>>> ITEMS;

    find_items(G, ITEMS, FOLLOW);

    cout << "分析表 ：" << endl;
    cout << "    ";
    for (int j = 0; j < 14; j++)
    {
        cout << ch[j] << "    ";
    }
    cout << endl;
    for (int i = 0; i < act.size(); i++)
    {
        cout << setw(2) << i << "  ";
        for (int j = 0; j < 14; j++)
        {
            cout << act[i][j].first << setiosflags(ios::left) << setw(2) << act[i][j].second << "  ";
        }
        cout << endl;
    }
    analysis(G, tar_str);

    return 0;
}

// 计算frist集
void find_frist(vector<pair<string, vector<string>>> &G, map<string, vector<string>> &FRIST, string &tar_c, vector<string> &tar_vec)
{
    for (int i = G.size() - 1; i >= 0; i--)
    {
        if (G[i].first == tar_c)
        {
            int f = 0;
            for (int j = 0; j < G[i].second.size(); j++)
            {
                string te = G[i].second[j];
                tar_vec.insert(tar_vec.end(), FRIST[te].begin(), FRIST[te].end());
                if (FRIST[te].back() != "~")
                {
                    f = 1;
                    break;
                }
                else
                {
                    tar_vec.pop_back();
                }
            }
            if (f == 0)
            {
                tar_vec.push_back("~");
            }
        }
        sort(tar_vec.begin(), tar_vec.end());
        tar_vec.erase(unique(tar_vec.begin(), tar_vec.end()), tar_vec.end());
        FRIST[tar_c] = tar_vec;
    }
}

// 计算follow集
void find_follow(vector<pair<string, vector<string>>> &G, map<string, vector<string>> &FOLLOW, map<string, vector<string>> &FRIST)
{
    for (int i = 9; i >= 0; i--)
    {
        for (int j = 0; j < G[i].second.size(); j++)
        {
            string te = G[i].second[j];

            if (!is_end_char(te) && te != "~")
            {
                int f = 0;
                for (int k = j + 1; k < G[i].second.size(); k++)
                {
                    string te2 = G[i].second[k];
                    FOLLOW[te].insert(FOLLOW[te].end(), FRIST[te2].begin(), FRIST[te2].end());
                    if (FOLLOW[te].back() != "~")
                    {
                        f = 1;
                        break;
                    }
                    else
                    {
                        FOLLOW[te].pop_back();
                    }
                }
                if (f == 0 && te != G[i].first)
                {
                    FOLLOW[te].insert(FOLLOW[te].end(), FOLLOW[G[i].first].begin(), FOLLOW[G[i].first].end());
                }
                sort(FOLLOW[te].begin(), FOLLOW[te].end());
                FOLLOW[te].erase(unique(FOLLOW[te].begin(), FOLLOW[te].end()), FOLLOW[te].end());
                f = 1;
            }
        }
    }
}

// 输出 FRIST 与 FOLLOW 与 SELECT集
void cout_set(map<string, vector<string>> &FOLLOW,
              map<string, vector<string>> &FRIST)
{
    cout << endl;
    cout << "------------------" << endl;
    cout << "FRIST : " << endl;
    for (int i = 0; i < 5; i++)
    {
        cout << setw(4) << no_end_c[i] << " :  ";
        for (int j = 0; j < FRIST[no_end_c[i]].size(); j++)
        {
            cout << setw(2) << FRIST[no_end_c[i]][j] << "  ";
        }
        cout << endl;
    }
    cout << "------------------" << endl;
    cout << "FOLLOW : " << endl;
    for (int i = 0; i < 5; i++)
    {
        cout << setw(4) << no_end_c[i] << " :  ";
        for (int j = 0; j < FOLLOW[no_end_c[i]].size(); j++)
        {
            cout << setw(2) << FOLLOW[no_end_c[i]][j] << "  ";
        }
        cout << endl;
    }
    cout << "------------------" << endl;
    cout << endl;
}

// 是否是终结符号
bool is_end_char(string &te)
{
    for (int i = 0; i < 7; i++)
    {
        if (te == end_c[i])
        {
            return true;
        }
    }
    return false;
}

// 计算closure集合
void find_closure(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &J, set<pair<int, int>> &I, map<string, vector<string>> &FOLLOW, int row)
{
    for (auto i = J.begin(); i != J.end(); i++)
    {
        I.insert(*i);
        if (i->second >= G[i->first].second.size())
        {
            continue;
        }
        string te = G[i->first].second[i->second];
        if (!is_end_char(te))
        {
            set<pair<int, int>> ts;
            for (int j = 0; j < G.size(); j++)
            {
                if (G[j].first == te && I.count(make_pair(j, 0)) == 0)
                {
                    ts.insert(make_pair(j, 0));
                    I.insert(make_pair(j, 0));
                }
            }
            if (!ts.empty())
                find_closure(G, ts, I, FOLLOW, row);
        }
    }
}

// 计算go集合
void find_go(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &I, set<pair<int, int>> &J, string &X, map<string, vector<string>> &FOLLOW, int row)
{
    for (auto i = I.begin(); i != I.end(); i++)
    {
        if (i->second >= G[i->first].second.size())
        {
            vector<string> &foll = FOLLOW[G[i->first].first];
            set<string> fo{begin(foll), end(foll)};
            for (int j = 0; j < 14; j++)
            {
                if (fo.count(ch[j]) == 1)
                {
                    act[row][j] = make_pair('R', i->first);
                }
            }
        }
        else
        {
            if (G[i->first].second[i->second] == X)
            {
                J.insert(make_pair(i->first, i->second + 1));
            }
        }
    }
}

// 计算分析表
void find_items(vector<pair<string, vector<string>>> &G, vector<set<pair<int, int>>> &ITEMS, map<string, vector<string>> &FOLLOW)
{
    set<pair<int, int>> initial = {make_pair(0, 0)};
    set<pair<int, int>> I0;
    find_closure(G, initial, I0, FOLLOW, 0);
    ITEMS.push_back(I0);

    for (int i = 0; i < ITEMS.size(); i++)
    {
        vector<pair<char, int>> te_act;
        te_act.resize(14);
        act.push_back(te_act);
        for (int j = 0; j < 14; j++)
        {
            set<pair<int, int>> te_J, te_I;
            find_go(G, ITEMS[i], te_J, ch[j], FOLLOW, i);
            if (!te_J.empty())
            {
                find_closure(G, te_J, te_I, FOLLOW, i);
                int f = 0;
                for (int k = 0; k < ITEMS.size(); k++)
                {
                    if (te_I == ITEMS[k])
                    {
                        act[i][j] = make_pair('S', k);
                        //cout << i << " => " << k << " " << ch[j] << endl;
                        f = 1;
                        break;
                    }
                }
                if (f == 1)
                {
                    continue;
                }
                ITEMS.push_back(te_I);
                act[i][j] = make_pair('S', ITEMS.size() - 1);
                //cout << i << " => " << ITEMS.size() << " " << ch[j] << endl;
                //cout<< "*****" << ITEMS.size() << "  ";
                //print_set(G, te_I);
                //cout << endl;
            }
        }
    }
    for (int i = 0; i < ITEMS.size(); i++)
    {
        cout << i << "  :  ";
        print_set(G, ITEMS[i]);
        cout << endl;
    }
}

void print_set(vector<pair<string, vector<string>>> &G, set<pair<int, int>> &te)
{
    for (auto i = te.begin(); i != te.end(); i++)
    {
        cout << G[i->first].first << "=>";
        int j = 0;
        for (; j < G[i->first].second.size(); j++)
        {
            if (i->second == j)
            {
                cout << "~";
            }
            cout << G[i->first].second[j];
        }
        if (i->second == j)
        {
            cout << "~";
        }
        cout << "  ";
    }
}

void analysis(vector<pair<string, vector<string>>> &G, vector<string> &tar_str)
{
    vector<pair<string, int>> st;
    st.push_back(make_pair(string(1, '^'), 0));
    int pos = 0;
    int wight = tar_str.size() * 1.2;
    int f_all = 1;
    while (f_all)
    {
        if (st.back().first == "S`")
        {
            f_all = 0;
        }
        for (int i = 0; i < st.size(); i++)
        {
            cout << st[i].first;
            cout << setiosflags(ios::left) << setw(2) << st[i].second;
        }
        for (int i = 0; i < wight - st.size(); i++)
        {
            cout << "   ";
        }
        cout << "   ";
        string temp;
        for (int i = pos; i < tar_str.size(); i++)
        {
            temp += tar_str[i];
        }
        cout << setiosflags(ios::right) << setw(wight) << temp << "   ";
        cout << resetiosflags(ios::right);

        int k = 0;
        for (; k < 8; k++)
        {
            if (tar_str[pos] == end_c[k])
            {
                break;
            }
        }
        pair<char, int> te = act[st.back().second][k];
        if (te.first == 'S')
        {
            st.push_back(make_pair(tar_str[pos], te.second));
            cout << te.first << te.second << "    ";
            pos++;
        }
        else if (te.first == 'R')
        {
            for (int j = 0; j < G[te.second].second.size(); j++)
            {
                st.pop_back();
            }
            string t_s = G[te.second].first;

            for (k = 8; k < 14; k++)
            {
                if (t_s == ch[k])
                {
                    break;
                }
            }
            cout << te.first << te.second << "    ";
            cout << act[st.back().second][k].second;
            st.push_back(make_pair(t_s, act[st.back().second][k].second));
        }
        else
        {
            if (!(st.back().first == "S`"))
            {
                cout << "字符串错误" << endl;
                break;
            }
        }

        cout << endl;
    }
}

// <ID,x34> <OP,=> <ID,a1> <OP,/> <ID,a2> <OP,*> <ID,a3>
// <ID,x34> <OP,=> <OP,/> <ID,a2> <OP,*> <ID,a3>

// <ID,i> <OP,=> <DE,(> <ID,i> <OP,+> <ID,i> <DE,)> <OP,+> <ID,i>
